#ifndef FARMITERATOR_H
#define FARMITERATOR_H

class FarmIterator
{
};

#endif
