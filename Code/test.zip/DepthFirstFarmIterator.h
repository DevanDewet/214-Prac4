#ifndef DEPTHFIRSTFARMITERATOR_H
#define DEPTHFIRSTFARMITERATOR_H

#include "FarmIterator.h"

class DepthFirstFarmIterator : public FarmIterator
{

};

#endif
