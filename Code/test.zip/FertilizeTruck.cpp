#include "FertilizeTruck.h"
#include <iostream>

void FertilizeTruck::startEngine() {
    std::cout << "Fertilize truck engine started. Delivering fertilizer.\n";
}
