#ifndef BREADTHFIRSTFARMITERATOR_H
#define BREADTHFIRSTFARMITERATOR_H

#include "FarmIterator.h"

class BreadthFirstFarmIterator : public FarmIterator
{
};

#endif
