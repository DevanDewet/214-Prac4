#ifndef TRUCKINTERFACE_H
#define TRUCKINTERFACE_H

class TruckInterface {
public:
    virtual void startEngine() = 0;
    virtual ~TruckInterface() {}
};

#endif
