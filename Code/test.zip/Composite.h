#ifndef COMPOSITE_H
#define COMPOSITE_H

#include"FarmUnit.h"

class Composite : FarmUnit
{
};

#endif
