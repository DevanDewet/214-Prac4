#include "DeliveryTruck.h"
#include <iostream>

void DeliveryTruck::startEngine() {
    std::cout << "Delivery truck engine started. Collecting crops.\n";
}
